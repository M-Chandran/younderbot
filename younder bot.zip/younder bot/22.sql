delete employee from employees
where mail = 'john.doe@company.com';