def rev(s):
    return s[::-1]
s = input("enter a string : ")
print("The reversed string is :",rev(s))