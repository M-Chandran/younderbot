insert into employee
values ('John', 'Doe', 'john.doe@example.com');