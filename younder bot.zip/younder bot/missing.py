def missing(nums):
 return n * (n + 1) // 2 - sum(nums)
n=10
nums = [1,2,3,4,5,6,7,8,9]
print("The missing number is : ",missing(nums))
