select name 
from employees
where salary > 40000;