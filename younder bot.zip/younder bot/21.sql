update salary 
from employee
where first name = 'John' and last name = 'Doe' and salary < 55000;